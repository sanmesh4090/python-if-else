num1=1

while num1<=10:
    print(num1)
    num1+=1
else:
    print("program ends")