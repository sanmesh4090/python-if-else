Emp={"Name":"Ram","Age":20,"salary":2000,"company":"TCS"}
print(type(Emp))
print("Printing Employee data")
print(Emp)
print("Name : ",Emp["Name"])