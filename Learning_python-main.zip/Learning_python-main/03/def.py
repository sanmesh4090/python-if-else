#---------------------------------------
def input (n1,n2):
    print(n1)
    print(n2)
print("Call to function")
input(1,2)
#---------------------------------------
def input (n1,n2=10):
    print(n1)
    print(n2)
print("Call to function")
input(1)
#---------------------------------------