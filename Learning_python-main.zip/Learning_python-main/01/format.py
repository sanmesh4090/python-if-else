# By using format function

amount = 23.333
print("Amount : ${:.2f}".format(amount))

print("python" , end="@")
print("\nG", "F","G" , sep=" ")
print("10", "07","2024" , sep=".")

# By using f String

name = "rohit"
age=20
print(f"hello , my name is {name} and i am {age} year old")

num = 20
add=num+10
print("The sum is %d"%add)
