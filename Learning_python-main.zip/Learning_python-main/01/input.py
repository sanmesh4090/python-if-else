fullname=input("Enter Your Name :")
print(fullname)

rollno=int(input("Enter Your Roll No :"))
print(rollno)